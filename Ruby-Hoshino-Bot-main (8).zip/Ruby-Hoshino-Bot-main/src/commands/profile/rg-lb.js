import { resolveIdentityName } from '../../core/identity-utils.js'
let handler = async (m, { conn, args, participants = [] }) => {
const page = parseInt(args[0]) || 1;
const pageSize = 10;
const startIndex = (page - 1) * pageSize;
const endIndex = startIndex + pageSize;
const participantJids = new Set(participants.map(p => p.jid || p.id).filter(Boolean));
const totalUsers = global.db.countUsers?.() || 0;
const totalPages = Math.max(1, Math.ceil(totalUsers / pageSize));
const pageUsers = (global.db.getTopUsers?.({ field: 'exp', limit: pageSize, offset: startIndex }) || global.db.topUsers?.({ field: 'exp', limit: pageSize, offset: startIndex }) || [])
.map(row => ({ jid: row.id, exp: Number(row.exp) || 0, level: Number(row.level) || 0 }));
let text = `◢✨ Top de usuarios con más experiencia ✨◤\n\n`;

const rows = [];
for (let i = 0; i < pageUsers.length; i++) {
const { jid, exp, level } = pageUsers[i];
const displayName = await resolveIdentityName(conn, jid, { fallback: `@${String(jid).split('@')[0]}` });
rows.push(`✰ ${startIndex + i + 1} » *${participantJids.has(jid) ? `(${displayName}) wa.me/` : '@'}${jid.split`@`[0]}*` +
`\n\t\t ❖ XP » *${exp}*  ❖ LVL » *${level}*`);
}
text += rows.join('\n');

text += `\n\n> • Página *${page}* de *${totalPages}*`;
if (page < totalPages) text += `\n> Para ver la siguiente página » *#lb ${page + 1}*`;

await conn.reply(m.chat, text.trim(), m, { mentions: conn.parseMention(text) });
}

handler.help = ['lb'];
handler.tags = ['rpg'];
handler.command = ['lboard', 'top', 'lb'];
handler.group = true;
handler.register = true;
handler.fail = null;
handler.exp = 0;

export default handler;
