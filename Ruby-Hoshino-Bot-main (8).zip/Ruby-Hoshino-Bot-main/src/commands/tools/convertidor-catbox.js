import crypto from "crypto";
import { fileTypeFromBuffer } from '../../library/fileType.js';

let handler = async (m, { conn }) => {
let q = m.quoted ? m.quoted : m;
let mime = (q.msg || q).mimetype || '';
if (!mime) {
await conn.reply(m.chat, `${emoji} Por favor, responda a un archivo válido (imagen, video, etc.).`, m);
return false;
}

await m.react(rwait);

try {
let media = await q.download();
let isTele = /image\/(png|jpe?g|gif)|video\/mp4/.test(mime);
let link = await catbox(media);

let txt = `*乂 C A T B O X - U P L O A D E R 乂*\n\n`;
txt += `*» Enlace* : ${link}\n`;
txt += `*» Tamaño* : ${formatBytes(media.length)}\n`;
txt += `*» Expiración* : ${isTele ? 'No expira' : 'Desconocido'}\n\n`;
txt += `> *${dev}*`;

await conn.sendFile(m.chat, media, 'thumbnail.jpg', txt, m, fkontak);

await m.react(done);
} catch (e) {
await m.react(error);
return false;
}
};

handler.help = ['tourl2'];
handler.tags = ['transformador'];
handler.command = ['catbox', 'tourl2'];
export default handler;

function formatBytes(bytes) {
if (bytes === 0) {
return '0 B';
}
const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
const i = Math.floor(Math.log(bytes) / Math.log(1024));
return `${(bytes / 1024 ** i).toFixed(2)} ${sizes[i]}`;
}

async function catbox(content) {
const { ext, mime } = (await fileTypeFromBuffer(content)) || {};
const blob = new Blob([content], { type: mime });
const formData = new FormData();
const randomBytes = crypto.randomBytes(5).toString("hex");
formData.append("reqtype", "fileupload");
formData.append("fileToUpload", blob, randomBytes + "." + ext);

const response = await fetch("https://catbox.moe/user/api.php", {
method: "POST",
body: formData,
headers: {
"User-Agent":
"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36",
},
});

return await response.text();
}
