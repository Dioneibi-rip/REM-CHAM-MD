import { resolveInteractionTarget, resolveIdentityName } from '../../core/identity-utils.js'

import fs from 'fs';
import path from 'path';

let handler = async (m, { conn, usedPrefix }) => {
let who = await resolveInteractionTarget(m, conn);

if (!global.db.getChat(m.chat).nsfw && m.isGroup) {
return m.reply(`${emoji} El contenido *NSFW* está desactivado en este grupo.\n> Un administrador puede activarlo con el comando » *#nsfw on*`);
}

let name = await resolveIdentityName(conn, who, { fallback: `@${String(who).split('@')[0]}` });
let name2 = await resolveIdentityName(conn, m.sender, { fallback: `@${String(m.sender).split('@')[0]}` });
m.react('🤰');

let str;
if (m.mentionedJid.length > 0) {
str = `\`${name2}\` *embarazo a* \`${name || who}\`.`;
} else if (m.quoted) {
str = `\`${name2}\` *embarazo a* \`${name || who}\`.`;
} else {
str = `\`${name2}\` *se embarazó a sí mismo >.<.*`.trim();
}

if (m.isGroup) {
let pp = 'https://qu.ax/uaYcl.mp4';
let pp2 = 'https://qu.ax/JqiKb.mp4';
let pp3 = 'https://qu.ax/uVokC.mp4';
let pp4 = 'https://qu.ax/NrcsJ.mp4';
let pp5 = 'https://qu.ax/hTGUg.mp4';
let pp6 = 'https://files.catbox.moe/brnwzh.mp4';
let pp7 = 'https://files.catbox.moe/3ucfc0.mp4';
let pp8 = 'https://files.catbox.moe/054z2h.mp4';

const videos = [pp, pp2, pp3, pp4, pp5, pp6, pp7, pp8];
const video = videos[Math.floor(Math.random() * videos.length)];

let mentions = [who];
conn.sendMessage(m.chat, { video: { url: video }, gifPlayback: true, caption: str, mentions }, { quoted: m });
}
}

handler.help = ['pregg/embarazar @tag'];
handler.tags = ['anime'];
handler.command = ['preg','embarazar','preñar'];
handler.group = true;

export default handler;
