import { nsfwWarning } from '../../library/respuesta.js';
import { resolveInteractionTarget } from '../../core/identity-utils.js'

import fs from 'fs';
import path from 'path';

let handler = async (m, { conn, usedPrefix }) => {
if (m.isGroup && !global.db.getChat(m.chat).nsfw) {
return m.reply(nsfwWarning());
}

let who = await resolveInteractionTarget(m, conn);

let name = await conn.getName(who);
let name2 = await conn.getName(m.sender);
m.react('🥵');

let str;
if (m.mentionedJid.length > 0) {
str = `\`${name2}\` *le hizo una paja con los pies a* \`${name || who}\`.`;
} else if (m.quoted) {
str = `\`${name2}\` *le hizo una paja con los pies a* \`${name || who}\`.`;
} else {
str = `\`${name2}\` *está haciendo una paja con los pies!*`.trim();
}

if (m.isGroup) {
let pp = 'https://qu.ax/aTGxj.mp4';
let pp2 = 'https://qu.ax/SCxhs.mp4';
let pp3 = 'https://qu.ax/ASKQT.mp4';
let pp4 = 'https://qu.ax/UQzPO.mp4';
let pp5 = 'https://qu.ax/yexqZ.mp4';
let pp6 = 'https://qu.ax/Agxmr.mp4';
let pp7 = 'https://qu.ax/dvgDr.mp4';

const videos = [pp, pp2, pp3, pp4, pp5, pp6, pp7];
const video = videos[Math.floor(Math.random() * videos.length)];

let mentions = [who];
conn.sendMessage(m.chat, { video: { url: video }, gifPlayback: true, caption: str, mentions }, { quoted: m });
}
}

handler.help = ['footjob/pies @tag'];
handler.tags = ['nsfw'];
handler.command = ['footjob','pies'];
handler.group = true;

export default handler;
